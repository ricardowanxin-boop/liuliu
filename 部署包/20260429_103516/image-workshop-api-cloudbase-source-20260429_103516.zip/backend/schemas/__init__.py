"""Pydantic response schemas."""
